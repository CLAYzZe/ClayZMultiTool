HI!
This is my multitool 
this is just a beta version.
full version of this multitool is coming soon
this is written in batch so you do not have to download anything if you have some problems 
when starting please contact clayzrepujekaolayz on discord
Thank you and be patient in anticipating the latest version.



You have to excract file 
if multitool does not work then run it individually 
or contract me to correct the error in the next update

Thank you for using ClayZMT